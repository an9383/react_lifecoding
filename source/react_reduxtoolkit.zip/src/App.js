import React from 'react';
function Counter() {
  return (
    <div>
      <button>+</button> 0
    </div>
  );
}

export default function App() {
  return (
    <div>
      <Counter></Counter>
    </div>
  );
}

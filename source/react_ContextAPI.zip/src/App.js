import React from 'react';
import './style.css';

export default function App() {
  return (
    <div>
      <h1>Hello World!</h1>
    </div>
  );
}
